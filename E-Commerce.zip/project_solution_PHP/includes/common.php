<?php
$con = mysqli_connect("localhost", "root", "aarti", "lifestylestore")or die($mysqli_error($con));
session_start();
